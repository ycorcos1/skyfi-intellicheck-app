"""
Lambda worker for SkyFi IntelliCheck company verification.
Handles external integrations and rule-based scoring.
"""

