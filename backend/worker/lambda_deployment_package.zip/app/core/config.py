"""Minimal config stub for Lambda worker - avoids pydantic-settings dependency."""
from functools import lru_cache
from typing import Optional

class Settings:
    """Stub Settings class - not used by worker."""
    def __init__(self):
        self.db_url: str = ""
        self.api_version: str = "1.0.0"
        self.environment: str = "development"
        self.host: str = "0.0.0.0"
        self.port: int = 8000
        self.cognito_region: str = "us-east-1"
        self.cognito_user_pool_id: Optional[str] = None
        self.cognito_app_client_id: Optional[str] = None
        self.cognito_issuer: Optional[str] = None
        self.git_sha: Optional[str] = None

@lru_cache
def get_settings() -> Settings:
    """Return stub settings - worker uses WorkerConfig instead."""
    return Settings()
