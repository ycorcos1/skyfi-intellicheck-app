"""Minimal database stub for Lambda worker - only provides Base for models."""
from sqlalchemy.ext.declarative import declarative_base

# Export Base for models to use
Base = declarative_base()

# Stub other exports that models might reference (not used by worker)
def get_db():
    """Stub - worker uses DatabaseManager instead."""
    raise NotImplementedError("Worker uses DatabaseManager, not get_db")
